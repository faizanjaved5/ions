<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/ApiClient.php';
require_once __DIR__ . '/ValidationHelper.php';

/**
 * CheckoutManager - Core checkout functionality
 * Extracted from Next.js checkout components
 */
class CheckoutManager 
{
    private $apiClient;
    private $validator;
    private $errors = [];
    private $sessionData = [];
    
    public function __construct() 
    {
        $this->apiClient = new ApiClient();
        $this->validator = new ValidationHelper();
        $this->initSession();
    }
    
    /**
     * Initialize session
     */
    private function initSession() 
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (!isset($_SESSION['checkout'])) {
            $_SESSION['checkout'] = [
                'csrf_token' => $this->generateCsrfToken(),
                'cart_items' => [],
                'customer_info' => [],
                'billing_address' => [],
                'shipping_address' => [],
                'payment_method' => null,
                'coupon_code' => null,
                'tax_amount' => 0,
                'total_amount' => 0
            ];
        }
        
        $this->sessionData = &$_SESSION['checkout'];
    }
    
    /**
     * Generate CSRF token
     */
    private function generateCsrfToken() 
    {
        return bin2hex(random_bytes(Config::CSRF_TOKEN_LENGTH));
    }
    
    /**
     * Validate CSRF token
     */
    public function validateCsrfToken($token) 
    {
        return hash_equals($this->sessionData['csrf_token'], $token);
    }
    
    /**
     * Add product to cart
     * Equivalent to Next.js increaseCartQuantity
     */
    public function addToCart($productData) 
    {
        try {
            // Validate product data
            $validation = $this->validator->validateProduct($productData);
            if (!$validation['valid']) {
                $this->errors = $validation['errors'];
                return false;
            }
            
            $productId = $productData['id'];
            $optionId = $productData['optionId'] ?? null;
            $quantity = (int)($productData['quantity'] ?? 1);
            
            // Check if item already exists in cart
            $cartKey = $productId . '_' . ($optionId ?? 'default');
            
            if (isset($this->sessionData['cart_items'][$cartKey])) {
                $this->sessionData['cart_items'][$cartKey]['quantity'] += $quantity;
            } else {
                $this->sessionData['cart_items'][$cartKey] = [
                    'id' => $productId,
                    'optionId' => $optionId,
                    'name' => $productData['name'],
                    'price' => (float)$productData['price'],
                    'quantity' => $quantity,
                    'type' => $productData['type'],
                    'unit' => $productData['unit'] ?? 'piece',
                    'currencyId' => $productData['currencyId'] ?? Config::DEFAULT_CURRENCY
                ];
            }
            
            $this->calculateTotals();
            return true;
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Remove item from cart
     */
    public function removeFromCart($productId, $optionId = null) 
    {
        $cartKey = $productId . '_' . ($optionId ?? 'default');
        
        if (isset($this->sessionData['cart_items'][$cartKey])) {
            unset($this->sessionData['cart_items'][$cartKey]);
            $this->calculateTotals();
            return true;
        }
        
        return false;
    }
    
    /**
     * Update customer information
     * Equivalent to Next.js form data processing
     */
    public function updateCustomerInfo($customerData) 
    {
        try {
            // Validate customer data
            $validation = $this->validator->validateCustomerInfo($customerData);
            if (!$validation['valid']) {
                $this->errors = $validation['errors'];
                return false;
            }
            
            $this->sessionData['customer_info'] = [
                'firstName' => $customerData['firstName'],
                'lastName' => $customerData['lastName'],
                'email' => $customerData['email'],
                'phone' => $customerData['phone'] ?? '',
                'dob' => $customerData['dob'] ?? '',
                'companyName' => $customerData['companyName'] ?? '',
                'customField1' => $customerData['customField1'] ?? '',
                'customField2' => $customerData['customField2'] ?? '',
                'customField3' => $customerData['customField3'] ?? '',
                'customField4' => $customerData['customField4'] ?? '',
                'customField5' => $customerData['customField5'] ?? ''
            ];
            
            return true;
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Update billing address
     */
    public function updateBillingAddress($addressData) 
    {
        try {
            $validation = $this->validator->validateAddress($addressData);
            if (!$validation['valid']) {
                $this->errors = $validation['errors'];
                return false;
            }
            
            $this->sessionData['billing_address'] = [
                'streetAddress' => $addressData['street'],
                'city' => $addressData['city'],
                'stateName' => $addressData['state'],
                'zip' => $addressData['zip'],
                'countryId' => $addressData['country']
            ];
            
            return true;
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Update shipping address
     */
    public function updateShippingAddress($addressData, $sameAsBilling = false) 
    {
        if ($sameAsBilling) {
            $this->sessionData['shipping_address'] = $this->sessionData['billing_address'];
            return true;
        }
        
        try {
            $validation = $this->validator->validateAddress($addressData);
            if (!$validation['valid']) {
                $this->errors = $validation['errors'];
                return false;
            }
            
            $this->sessionData['shipping_address'] = [
                'streetAddress' => $addressData['street'],
                'city' => $addressData['city'],
                'stateName' => $addressData['state'],
                'zip' => $addressData['zip'],
                'countryId' => $addressData['country']
            ];
            
            return true;
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Apply coupon code
     */
    public function applyCoupon($couponCode, $tenantId) 
    {
        try {
            $couponInfo = $this->apiClient->getCouponInfo($couponCode, $tenantId);
            
            if ($couponInfo && $couponInfo['valid']) {
                $this->sessionData['coupon_code'] = $couponCode;
                $this->sessionData['coupon_discount'] = $couponInfo['discount'];
                $this->calculateTotals();
                return true;
            } else {
                $this->errors[] = Config::getErrorMessage('COUPON_INVALID');
                return false;
            }
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Calculate totals including tax and discounts
     */
    private function calculateTotals() 
    {
        $subtotal = 0;
        
        foreach ($this->sessionData['cart_items'] as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }
        
        // Apply coupon discount
        $discount = 0;
        if (isset($this->sessionData['coupon_discount'])) {
            $discount = $this->sessionData['coupon_discount'];
        }
        
        $discountedSubtotal = $subtotal - $discount;
        
        // Calculate tax if enabled
        $tax = 0;
        if (Config::TAX_CALCULATION_ENABLED) {
            // Tax calculation would be implemented here
            // For MVP, we'll use a simple 8% tax rate
            $tax = $discountedSubtotal * 0.08;
        }
        
        $this->sessionData['subtotal'] = $subtotal;
        $this->sessionData['discount'] = $discount;
        $this->sessionData['tax_amount'] = $tax;
        $this->sessionData['total_amount'] = $discountedSubtotal + $tax;
    }
    
    /**
     * Submit payment request to Sperse API
     * Equivalent to Next.js getSubmitRequest function
     */
    public function submitPaymentRequest($paymentGateway, $tenantId) 
    {
        try {
            // Validate checkout data
            if (!$this->validateCheckoutData()) {
                return false;
            }
            
            // Prepare product data
            $products = [];
            foreach ($this->sessionData['cart_items'] as $item) {
                $products[] = [
                    'productId' => (int)$item['id'],
                    'optionId' => $item['optionId'] ? (int)$item['optionId'] : null,
                    'unit' => $item['unit'],
                    'price' => (float)$item['price'],
                    'quantity' => (int)$item['quantity']
                ];
            }
            
            // Prepare request data
            $requestData = [
                'products' => $products,
                'tenantId' => (int)$tenantId,
                'paymentGateway' => $paymentGateway,
                'embeddedPayment' => false,
                'firstName' => $this->sessionData['customer_info']['firstName'],
                'lastName' => $this->sessionData['customer_info']['lastName'],
                'email' => $this->sessionData['customer_info']['email'],
                'phone' => $this->sessionData['customer_info']['phone'],
                'successUrl' => $this->getSuccessUrl($tenantId),
                'cancelUrl' => $this->getCancelUrl()
            ];
            
            // Add optional fields
            if (!empty($this->sessionData['coupon_code'])) {
                $requestData['couponCode'] = $this->sessionData['coupon_code'];
            }
            
            if (!empty($this->sessionData['billing_address'])) {
                $requestData['billingAddress'] = $this->sessionData['billing_address'];
            }
            
            if (!empty($this->sessionData['shipping_address'])) {
                $requestData['shippingAddress'] = $this->sessionData['shipping_address'];
            }
            
            // Submit to API
            $response = $this->apiClient->submitProductRequest($requestData);
            
            if ($response && isset($response['paymentData'])) {
                return [
                    'success' => true,
                    'paymentUrl' => $response['paymentData'],
                    'invoiceId' => $response['initialInvoicePublicId'] ?? null
                ];
            } else {
                $this->errors[] = Config::getErrorMessage('PAYMENT_FAILED');
                return false;
            }
            
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }
    
    /**
     * Validate all checkout data before submission
     */
    private function validateCheckoutData() 
    {
        $valid = true;
        $this->errors = [];
        
        // Check cart has items
        if (empty($this->sessionData['cart_items'])) {
            $this->errors[] = 'Cart is empty';
            $valid = false;
        }
        
        // Check customer info
        if (empty($this->sessionData['customer_info']['firstName']) || 
            empty($this->sessionData['customer_info']['lastName']) ||
            empty($this->sessionData['customer_info']['email'])) {
            $this->errors[] = 'Customer information is incomplete';
            $valid = false;
        }
        
        return $valid;
    }
    
    /**
     * Get success URL
     */
    private function getSuccessUrl($tenantId) 
    {
        $baseUrl = $this->getBaseUrl();
        return $baseUrl . "/success.php?tenant={$tenantId}&invoice={initialInvoiceXref}";
    }
    
    /**
     * Get cancel URL
     */
    private function getCancelUrl() 
    {
        return $this->getBaseUrl() . "/checkout.php";
    }
    
    /**
     * Get base URL
     */
    private function getBaseUrl() 
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        return $protocol . '://' . $host;
    }
    
    /**
     * Get current errors
     */
    public function getErrors() 
    {
        return $this->errors;
    }
    
    /**
     * Get session data
     */
    public function getSessionData() 
    {
        return $this->sessionData;
    }
    
    /**
     * Clear checkout session
     */
    public function clearSession() 
    {
        unset($_SESSION['checkout']);
        $this->initSession();
    }
}

?>
